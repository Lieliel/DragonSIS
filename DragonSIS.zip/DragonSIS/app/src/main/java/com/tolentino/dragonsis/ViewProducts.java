package com.tolentino.dragonsis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewProducts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products2);
    }
}